"use client";

import { createContext, useContext, useState, useEffect, useCallback, ReactNode } from "react";
import { BudgetAssumptions, ResourceLine, OtherCost, GomResult, calculateProjectGom } from "@/lib/gom-calculator";
import { DEFAULT_ASSUMPTIONS } from "../components/AssumptionsView";
import { apiClient, API_URL, getAuthHeaders } from "@/lib/api";

interface ResourceRow {
    id: string;
    role: string;
    baseLocation: string;
    deliveryFrom: string;
    type: "Offshore" | "Onsite";
    annualCTC: number;
    dailyCost: number;
    dailyRate: number;
    monthlyEfforts: Record<string, number>; // month -> days
}

interface TravelCosts {
    modeOfTravel: string;
    frequency: string;
    roundTripCost: number;
    medicalInsurance: number;
    visaCost: number;
    vaccineCost: number;
    localConveyance: number;
    marketingCom: number;
    hotelCost: number;
}

interface OpportunityEstimationContextType {
    // Assumptions
    assumptions: BudgetAssumptions;
    setAssumptions: (assumptions: BudgetAssumptions) => void;

    // Resource Assignment
    resources: ResourceRow[];
    setResources: (resources: ResourceRow[]) => void;
    selectedYear: number;
    setSelectedYear: (year: number) => void;

    // Travel Costs
    travelCosts: TravelCosts;
    setTravelCosts: (costs: TravelCosts) => void;

    // GOM Calculation Inputs
    markupPercent: number;
    setMarkupPercent: (markup: number) => void;
    salesCommissionPercent: number;
    setSalesCommissionPercent: (val: number) => void;
    preSalesCostPercent: number;
    setPreSalesCostPercent: (val: number) => void;
    currency: string;
    setCurrency: (currency: string) => void;
    effortType: string;
    setEffortType: (type: string) => void;

    // Calculated Values
    totalResourceCost: number;
    totalTravelCost: number;
    salesCommissionAmount: number;
    preSalesCostAmount: number;
    totalCost: number;
    revenue: number;
    gomPercent: number;
    gomStatus: { text: string; color: string };

    // GOM Summary
    gomSummary: GomResult | null;
    months: string[];
    otherCosts: OtherCost[];

    // Persistence
    saveEstimation: () => Promise<void>;
    isSaving: boolean;
    isLoaded: boolean;

    // Read-only mode (when estimation submitted)
    readOnly: boolean;

    // Date range for calendar columns
    startDate: string;
    endDate: string;
}

const OpportunityEstimationContext = createContext<OpportunityEstimationContextType | undefined>(undefined);

export function OpportunityEstimationProvider({ children, opportunityId, readOnly = false, startDate = '', endDate = '', adjustedEstimatedValue = 0 }: { children: ReactNode; opportunityId?: string; readOnly?: boolean; startDate?: string; endDate?: string; adjustedEstimatedValue?: number }) {
    // State
    const [assumptions, setAssumptions] = useState<BudgetAssumptions>(DEFAULT_ASSUMPTIONS);
    const [resources, setResources] = useState<ResourceRow[]>([]);
    const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
    const [travelCosts, setTravelCosts] = useState<TravelCosts>({
        modeOfTravel: "",
        frequency: "",
        roundTripCost: 0,
        medicalInsurance: 0,
        visaCost: 0,
        vaccineCost: 0,
        localConveyance: 0,
        marketingCom: 0,
        hotelCost: 0,
    });
    const [markupPercent, setMarkupPercentRaw] = useState<number>(0);
    const [salesCommissionPercent, setSalesCommissionPercent] = useState<number>(0);
    const [preSalesCostPercent, setPreSalesCostPercent] = useState<number>(0);
    const [currency, setCurrency] = useState<string>("INR");
    const [effortType, setEffortType] = useState<string>("QBA");
    const [isSaving, setIsSaving] = useState(false);
    const [isLoaded, setIsLoaded] = useState(false);

    // Wrap setMarkupPercent to also recalculate all resources' dailyRate
    const setMarkupPercent = useCallback((newMarkup: number) => {
        setMarkupPercentRaw(newMarkup);
        setResources(prev => prev.map(r => ({
            ...r,
            dailyRate: r.dailyCost * (1 + newMarkup / 100),
        })));
    }, []);

    // Fetch budget assumptions from admin settings
    useEffect(() => {
        (async () => {
            try {
                const data = await apiClient("/api/admin/budget-assumptions");
                if (data && typeof data === "object") {
                    setAssumptions({ ...DEFAULT_ASSUMPTIONS, ...data });
                }
            } catch {
                // Silently use defaults if API fails
            }
        })();
    }, []);

    // Load saved estimation data from the opportunity record
    useEffect(() => {
        if (!opportunityId) { setIsLoaded(true); return; }
        (async () => {
            try {
                const res = await fetch(`${API_URL}/api/opportunities/${opportunityId}`, { headers: getAuthHeaders() });
                if (!res.ok) { setIsLoaded(true); return; }
                const opp = await res.json();
                const saved = opp.presalesData;
                if (saved && typeof saved === "object" && !Array.isArray(saved)) {
                    // Restore estimation data (skip if it's the old modal-only format)
                    if (saved.resources) setResources(saved.resources);
                    if (saved.travelCosts) setTravelCosts(prev => ({ ...prev, ...saved.travelCosts }));
                    if (saved.markupPercent != null) setMarkupPercent(saved.markupPercent);
                    if (saved.salesCommissionPercent != null) setSalesCommissionPercent(saved.salesCommissionPercent);
                    if (saved.preSalesCostPercent != null) setPreSalesCostPercent(saved.preSalesCostPercent);
                    if (saved.currency) setCurrency(saved.currency);
                    if (saved.effortType) setEffortType(saved.effortType);
                    if (saved.selectedYear) setSelectedYear(saved.selectedYear);
                }
            } catch {
                // silently use defaults
            } finally {
                setIsLoaded(true);
            }
        })();
    }, [opportunityId]);

    // Save estimation data to the opportunity record
    const saveEstimation = useCallback(async () => {
        if (!opportunityId) return;
        setIsSaving(true);
        try {
            const payload = {
                presalesData: {
                    resources,
                    travelCosts,
                    markupPercent,
                    salesCommissionPercent,
                    preSalesCostPercent,
                    currency,
                    effortType,
                    selectedYear,
                },
            };
            await fetch(`${API_URL}/api/opportunities/${opportunityId}`, {
                method: "PATCH",
                headers: getAuthHeaders(),
                body: JSON.stringify(payload),
            });
        } finally {
            setIsSaving(false);
        }
    }, [opportunityId, resources, travelCosts, markupPercent, salesCommissionPercent, preSalesCostPercent, currency, effortType, selectedYear]);

    // Calculated values
    const [totalResourceCost, setTotalResourceCost] = useState(0);
    const [totalTravelCost, setTotalTravelCost] = useState(0);
    const [salesCommissionAmount, setSalesCommissionAmount] = useState(0);
    const [preSalesCostAmount, setPreSalesCostAmount] = useState(0);
    const [totalCost, setTotalCost] = useState(0);
    const [revenue, setRevenue] = useState(0);
    const [gomPercent, setGomPercent] = useState(0);
    const [gomSummary, setGomSummary] = useState<GomResult | null>(null);
    const [months, setMonths] = useState<string[]>([]);
    const [otherCosts, setOtherCosts] = useState<OtherCost[]>([]);

    // Calculate months from resources
    useEffect(() => {
        const allMonths = new Set<string>();
        resources.forEach(resource => {
            Object.keys(resource.monthlyEfforts).forEach(month => {
                if (resource.monthlyEfforts[month] > 0) {
                    // Convert month name to YYYY-MM format
                    const monthIndex = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"].indexOf(month);
                    if (monthIndex !== -1) {
                        const monthStr = `${selectedYear}-${String(monthIndex + 1).padStart(2, '0')}`;
                        allMonths.add(monthStr);
                    }
                }
            });
        });
        setMonths(Array.from(allMonths).sort());
    }, [resources, selectedYear]);

    // Calculate total travel cost
    useEffect(() => {
        const total = travelCosts.roundTripCost +
            travelCosts.medicalInsurance +
            travelCosts.visaCost +
            travelCosts.vaccineCost +
            travelCosts.localConveyance +
            travelCosts.marketingCom +
            travelCosts.hotelCost;
        setTotalTravelCost(total);
    }, [travelCosts]);

    // Calculate resource cost and GOM
    useEffect(() => {
        // Convert resources to ResourceLine format
        const resourceLines: ResourceLine[] = resources.map(resource => {
            const monthsData: { month: string; days: number }[] = [];

            Object.entries(resource.monthlyEfforts).forEach(([monthName, days]) => {
                if (days > 0) {
                    const monthIndex = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"].indexOf(monthName);
                    if (monthIndex !== -1) {
                        const monthStr = `${selectedYear}-${String(monthIndex + 1).padStart(2, '0')}`;
                        monthsData.push({ month: monthStr, days });
                    }
                }
            });

            return {
                id: resource.id,
                role: resource.role,
                location: resource.type,
                dailyRate: resource.dailyRate,
                dailyCost: resource.dailyCost,
                months: monthsData,
            };
        });

        // Calculate total resource cost
        let resCost = 0;
        resourceLines.forEach(line => {
            line.months.forEach(m => {
                resCost += m.days * line.dailyCost;
            });
        });
        setTotalResourceCost(resCost);

        // Create other costs for travel (distribute across months if needed)
        const otherCosts: OtherCost[] = [];
        if (totalTravelCost > 0) {
            // Determine month for travel cost: first resource month, or derive from start date
            let travelMonth = months.length > 0 ? months[0] : null;
            if (!travelMonth && startDate) {
                const d = new Date(startDate);
                travelMonth = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
            }
            if (!travelMonth) {
                travelMonth = `${selectedYear}-01`;
            }
            otherCosts.push({
                id: "travel-1",
                description: "Travel & Hospitality",
                amount: totalTravelCost,
                month: travelMonth,
                category: "Travel + Stay",
            });
        }
        setOtherCosts(otherCosts);

        // Calculate GOM Summary
        if (resourceLines.length > 0) {
            const summary = calculateProjectGom(resourceLines, otherCosts, assumptions);
            setGomSummary(summary);

            // Calculate Base Cost
            const baseCost = resCost + totalTravelCost;

            // Use adjustedEstimatedValue as revenue if provided, otherwise use markup calculation
            // Base Cost is used for markup to determine the sale price.
            const calculatedRevenue = adjustedEstimatedValue > 0
                ? adjustedEstimatedValue
                : baseCost * (1 + markupPercent / 100);
            
            setRevenue(calculatedRevenue);

            // Calculate Additional Costs based on Revenue
            const commAmount = calculatedRevenue * (salesCommissionPercent / 100);
            const preSalesAmount = calculatedRevenue * (preSalesCostPercent / 100);
            
            setSalesCommissionAmount(commAmount);
            setPreSalesCostAmount(preSalesAmount);

            // Final Total Cost includes these additional components
            const finalCost = baseCost + commAmount + preSalesAmount;
            setTotalCost(finalCost);

            const gom = calculatedRevenue > 0 ? ((calculatedRevenue - finalCost) / calculatedRevenue) * 100 : 0;
            setGomPercent(gom);
        } else {
            // No resources, simple calculation
            const baseCost = totalTravelCost;
            
            const calculatedRevenue = adjustedEstimatedValue > 0
                ? adjustedEstimatedValue
                : baseCost * (1 + markupPercent / 100);
            
            setRevenue(calculatedRevenue);

            const commAmount = calculatedRevenue * (salesCommissionPercent / 100);
            const preSalesAmount = calculatedRevenue * (preSalesCostPercent / 100);

            setSalesCommissionAmount(commAmount);
            setPreSalesCostAmount(preSalesAmount);

            const finalCost = baseCost + commAmount + preSalesAmount;
            setTotalCost(finalCost);

            const gom = calculatedRevenue > 0 ? ((calculatedRevenue - finalCost) / calculatedRevenue) * 100 : 0;
            setGomPercent(gom);
            setGomSummary(null);
        }
    }, [resources, totalTravelCost, markupPercent, salesCommissionPercent, preSalesCostPercent, assumptions, selectedYear, months, adjustedEstimatedValue, startDate]);

    // Determine GOM status
    const getGomStatus = () => {
        if (gomPercent >= 30) return { text: "Approved", color: "text-green-600 bg-green-50 border-green-200" };
        if (gomPercent >= 20) return { text: "Review", color: "text-amber-600 bg-amber-50 border-amber-200" };
        return { text: "Rejected", color: "text-red-600 bg-red-50 border-red-200" };
    };

    const value: OpportunityEstimationContextType = {
        assumptions,
        setAssumptions,
        resources,
        setResources,
        selectedYear,
        setSelectedYear,
        travelCosts,
        setTravelCosts,
        markupPercent,
        setMarkupPercent,
        salesCommissionPercent,
        setSalesCommissionPercent,
        preSalesCostPercent,
        setPreSalesCostPercent,
        currency,
        setCurrency,
        effortType,
        setEffortType,
        totalResourceCost,
        totalTravelCost,
        salesCommissionAmount,
        preSalesCostAmount,
        totalCost,
        revenue,
        gomPercent,
        gomStatus: getGomStatus(),
        gomSummary,
        months,
        otherCosts,
        saveEstimation,
        isSaving,
        isLoaded,
        readOnly,
        startDate,
        endDate,
    };

    return (
        <OpportunityEstimationContext.Provider value={value}>
            {children}
        </OpportunityEstimationContext.Provider>
    );
}

export function useOpportunityEstimation() {
    const context = useContext(OpportunityEstimationContext);
    if (context === undefined) {
        throw new Error("useOpportunityEstimation must be used within OpportunityEstimationProvider");
    }
    return context;
}

export type { ResourceRow, TravelCosts };
